package com.mypage.project.board.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mypage.project.board.Board;

public interface BoardRepository extends JpaRepository<Board, Integer> {
	
	
	
	
}
